#!/usr/bin/python3
python3 /home/ctf/prob.py
