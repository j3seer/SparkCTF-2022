cd /home/ctf/
gunzip initramfs.cpio.gz
mkdir initramfs
cd initramfs
cpio -idm < ../initramfs.cpio
rm -rf flag
cp /home/ctf/flag /home/ctf/initramfs/

find . -print0 | cpio --null -ov --format=newc | gzip -9 > initramfs.cpio.gz
mv ./initramfs.cpio.gz /home/ctf/

rm -rf /home/ctf/{initramfs,initramfs.cpio}