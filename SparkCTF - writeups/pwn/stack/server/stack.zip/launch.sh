#!/bin/sh
cd /home/ctf/ && ./chall